from __future__ import annotations

import threading

from enum import IntEnum
import logging
from typing import Callable, Type, TypeVar
from types import TracebackType
import time

import smbus2
from RPi import GPIO
from bmh import crc

_LOGGER = logging.getLogger(__name__)

VERSION = 0
TRACE_MESSAGES = False

PANEL_MASK = 0x70
PANEL_IO = 0x10
PANEL_1W = 0x20

T = TypeVar("T")

class CrcError(IOError):
    """Raised when CRC error occurs on the bus."""

class Bus:
    # pylint: disable=too-many-instance-attributes
    def __init__(self, bus_id: int, i2c_id: int, interrupt_pin: int) -> None:
        self.__id = bus_id
        self.__interrupt_pin = interrupt_pin

        self.__lock = threading.RLock()

        self.__smbus = smbus2.SMBus(i2c_id)

        self.__messages = 0
        self.__errors = 0
        self.__retries = 3

        self.__scanned = False
        self.__device_dict: dict[int, Device] = {}
        self.__device_list: list[Device] = []
        self.__interrupts = 0
        self.__interrupt_traversal: list[int] = []

        self.__interrupt_handler: Callable[[Device, int], None] | None = None

        GPIO.setup(interrupt_pin, GPIO.IN, pull_up_down = GPIO.PUD_UP)
        GPIO.add_event_detect(interrupt_pin, GPIO.FALLING,
                              callback = self.__interrupt, bouncetime = 1)

    def close(self) -> None:
        with self.__lock:
            GPIO.remove_event_detect(self.__interrupt_pin)
            self.__smbus.close()

    @property
    def id(self) -> int:
        return self.__id

    @property
    def messages(self) -> int:
        return self.__messages

    @property
    def errors(self) -> int:
        return self.__errors

    @property
    def retries(self) -> int:
        return self.__retries

    @retries.setter
    def retries(self, retries: int) -> None:
        if retries <= 0:
            raise ValueError(f"Wrong retries: {retries}")

        self.__retries = retries

    @staticmethod
    def __dump(read_write: str, address: int, msg: smbus2.i2c_msg) -> None:
        if not TRACE_MESSAGES:
            return
        if not _LOGGER.isEnabledFor(logging.DEBUG):
            return

        _LOGGER.debug("-- %s(0x%02X): [%s]", read_write, address,
                      bytes(msg).hex(" ").upper())

    def __transfer_msg(self, address: int, write: smbus2.i2c_msg,
                       read: smbus2.i2c_msg, retry: bool) -> None:
        Bus.__dump("write", address, write)

        if retry:
            # we are sending messages separately when retrying
            self.__smbus.i2c_rdwr(write)
            self.__smbus.i2c_rdwr(read)
        else:
            self.__smbus.i2c_rdwr(write, read)

        Bus.__dump("read", address, read)

    def __try_transfer(self, address: int, request: bytes,
                       response_length: int, retry: bool) -> bytes:
        request_crc = crc.generate(bytes([address]) + request)
        full_request = request + bytes([request_crc])

        msg1 = smbus2.i2c_msg.write(address, full_request)
        msg2 = smbus2.i2c_msg.read(address, response_length + 1)

        with self.__lock:
            self.__transfer_msg(address, msg1, msg2, retry)

        full_response = bytes(msg2)
        response = full_response[:response_length]

        expected_crc = crc.generate(bytes([response_length + 1]) + response)
        response_crc = full_response[response_length]

        if response_crc != expected_crc:
            if response[0] == 0x66:
                raise CrcError("CRC error during send.")
            if response[0] == 0x77:
                raise IOError(f"Unknown register '0x{request[0]:02X}'.")

            raise CrcError(f"Crc error. Expected: 0x{expected_crc:02X}, "
                           f"Got: 0x{response_crc:02X}")

        return response

    def __transfer(self, address: int, request: bytes,
                   response_length: int) -> bytes:
        if len(request) < 1:
            raise ValueError("Request is too short.")
        if response_length < 0:
            raise ValueError("Response length cannot be negative.")

        for i in range(0, self.retries):
            try:
                retry = i > 0

                self.__messages += 1

                return self.__try_transfer(address, request,
                                           response_length, retry)
            except IOError as error:
                if isinstance(error, CrcError):
                    _LOGGER.warning(error)
                else:
                    _LOGGER.warning("Command failed.", exc_info=error)

                self.__errors += 1
                last_error = error

        _LOGGER.error("Command failed after '%d' retries.", self.retries)

        raise IOError(f"Command failed after '{self.retries}' retries.") \
                from last_error

    def read(self, address: int, command: int,
             response_length: int = 1) -> bytes:
        return self.__transfer(address, bytes([command]), response_length)

    def read_int(self, address: int, command: int,
                 response_length: int = 1) -> int:
        response = self.read(address, command, response_length)

        return int.from_bytes(response, byteorder="big")

    def write(self, address: int, command: int, request: bytes) -> None:
        self.__transfer(address, bytes([command]) + request, 0)

    def write_int(self, address: int, command: int, request: int,
                  request_length: int = 1) -> None:
        self.write(address, command,
                   request.to_bytes(request_length, byteorder="big"))

    def __first_scan(self) -> None:
        with self.__lock:
            if not self.__scanned:
                self.scan()

    def get_device(self, address: int) -> Device:
        self.__first_scan()

        if address not in self.__device_dict:
            raise ValueError(f"Unknown address '0x{address:02X}' "
                             f"on bus '{self.__id}'.")

        return self.__device_dict[address]

    def get_devices(self) -> list[Device]:
        self.__first_scan()

        return self.__device_list

    @property
    def interrupts(self) -> int:
        return self.__interrupts

    @property
    def interrupt_handler(self) -> Callable[[Device, int], None] | None:
        return self.__interrupt_handler

    @interrupt_handler.setter
    def interrupt_handler(self,
            interrupt_handler: Callable[[Device, int], None] | None) -> None:
        # initiating a scan, because the interrupt flag can be present
        self.__first_scan()

        with self.__lock:
            self.__interrupt_handler = interrupt_handler
            call_interrupt_handler = self.is_interrupt()

        if call_interrupt_handler:
            self.__interrupt()

    def __call_interrupt_handler(self,
            interrupt_handler: Callable[[Device, int], None],
            devices: dict[Device, int]) -> None:
        for device, interrupt_status in devices.items():
            _LOGGER.debug("Interrupting device is '0x%02X' with "
                          "status '0x%04X'.", device.address, interrupt_status)
            interrupt_handler(device, interrupt_status)

    def __interrupt(self, _channel: int = 0) -> None:
        # sometimes the interrupt handler called twice
        if not self.is_interrupt():
            return

        with self.__lock:
            interrupt_handler = self.__interrupt_handler

            if interrupt_handler is None:
                return

            _LOGGER.debug("Interrupt on bus %d.", self.__id)

            self.__interrupts += 1

            interrupted_devices1 = self.__get_interrupted_devices()
            interrupted_devices2 = {}

            if self.is_interrupt():
                # If interrupt is still present, it probably means that a new
                # device was added, but it is missing from the traversal list.
                _LOGGER.warning("Interrupt is still present, "
                                "initiating a scan.")

                self.scan()
                interrupted_devices2 = self.__get_interrupted_devices()

                if self.is_interrupt():
                    _LOGGER.warning("Could not find interrupting device "
                                    "after scan.")

        self.__call_interrupt_handler(interrupt_handler, interrupted_devices1)
        self.__call_interrupt_handler(interrupt_handler, interrupted_devices2)

    def __get_interrupted_devices(self) -> dict[Device, int]:
        interrupted_devices = {}
        new_traversal_first = []
        new_traversal_middle = []
        new_traversal_last = []

        # We are searching for interrupted devices while bus.is_interrupt() is
        # true. The search order is based on interrupt_traversal list. This
        # list is maintained to contain the most recent interrupt raising
        # devices in order.
        for address in self.__interrupt_traversal:
            device = self.__device_dict[address]

            try:
                if self.is_interrupt():
                    interrupt_status = device.get_interrupt_status(True)
                else:
                    interrupt_status = 0

                if interrupt_status > 0:
                    device._interrupts += 1

                    interrupted_devices[device] = interrupt_status
                    new_traversal_first.append(address)
                else:
                    new_traversal_middle.append(address)
            except IOError as error:
                _LOGGER.warning("Device '0x%02X' is not present: %s",
                                address, error)
                # inserting last, so next time we probably won't reach it
                new_traversal_last.append(address)

        self.__interrupt_traversal = \
                new_traversal_first + new_traversal_middle + new_traversal_last

        return interrupted_devices

    def is_interrupt(self) -> bool:
        return not GPIO.input(self.__interrupt_pin)

    def __check_device(self, address: int) -> int:
        # Device checking is pretty tricky, because if a device is not
        # present, we will get an IOError. However there can be communication
        # issues, so we must handle CrcErrors.

        # we are increasing __messages for successful reads and crc errors
        # we are increasing __errors only for crc errors
        for i in range(0, self.retries):
            try:
                retry = i > 0
                response = self.__try_transfer(address, bytes([0xFF]), 2, retry)

                self.__messages += 1

                return int.from_bytes(response, byteorder="big")
            except CrcError as error:
                last_error = error

                self.__messages += 1
                self.__errors += 1

        raise last_error

    def __create_device(self, address: int, version: int) -> Device:
        panel = address & PANEL_MASK

        if panel == PANEL_IO:
            return DeviceIo(self, address, version)
        elif panel == PANEL_1W:
            return Device1w(self, address, version)
        else:
            return Device(self, address, version)

    def __try_device(self, address: int) -> Device | None:
        try:
            # reading device version but retrying only CRC errors
            version = self.__check_device(address)

            if version > VERSION:
                _LOGGER.warning("Device '0x%02X' version is '%d' which is "
                                "newer than supported '%d'.",
                                address, version, VERSION)
                return None

            if address in self.__device_dict:
                device = self.__device_dict[address]
                # pylint: disable=protected-access
                device._version = version
            else:
                device = self.__create_device(address, version)

            return device
        except CrcError as error:
            _LOGGER.error("Could not get device '0x%02X' version.",
                          address, exc_info=error)
            return None
        except IOError:
            return None

    def scan(self) -> list[Device]:
        with self.__lock:
            self.__scanned = True

            new_device_dict: dict[int, Device] = {}
            new_device_addresses: list[int] = []

            try:
                for address in range(0x10, 0x70):
                    device = self.__try_device(address)

                    if device is None:
                        continue

                    new_device_dict[address] = device

                    if address not in self.__device_dict:
                        new_device_addresses.append(address)
            except TimeoutError:
                # no devices on the bus
                pass

            new_device_list = sorted(new_device_dict.values(),
                                     key = lambda device: device.address)

            new_interrupt_traversal = []

            for address in self.__interrupt_traversal:
                if address in new_device_dict:
                    new_interrupt_traversal.append(address)

            for address in new_device_addresses:
                new_interrupt_traversal.append(address)

            self.__device_dict = new_device_dict
            self.__device_list = new_device_list
            self.__interrupt_traversal = new_interrupt_traversal

        return self.get_devices()

    def __str__(self) -> str:
        return f"Bus[id={self.__id}, interrupt={self.__interrupt_pin}]"

class Reset(IntEnum):
    NORMAL = 0
    MANUAL = 1
    WATCHDOG = 2

class Device:
    def __init__(self, bus: Bus, address: int, version: int):
        self.__bus = bus
        self.__address = address
        self._version = version
        self._interrupts = 0

    @property
    def type(self) -> str:
        return "Unknown"

    @property
    def bus(self) -> Bus:
        return self.__bus

    @property
    def address(self) -> int:
        return self.__address

    @property
    def version(self) -> int:
        return self._version

    @property
    def id(self) -> int:
        return self.bus.id << 8 | self.address

    @property
    def interrupts(self) -> int:
        return self._interrupts

    def read(self, command: int, response_length: int = 1) -> bytes:
        return self.__bus.read(self.__address, command, response_length)

    def read_int(self, command: int, response_length: int = 1) -> int:
        return self.__bus.read_int(self.__address, command, response_length)

    def write(self, command: int, request: bytes) -> None:
        self.__bus.write(self.__address, command, request)

    def write_int(self, command: int, request: int,
                  request_length: int = 1) -> None:
        self.__bus.write_int(self.__address, command, request, request_length)

    def get_interrupt_status(self, clear_interrupt: bool = False) -> int:
        if clear_interrupt:
            return self.read_int(0xFA, 2)
        else:
            return self.read_int(0xF9, 2)

    def get_interrupt_mask(self) -> int:
        return self.read_int(0xFB, 2)

    def set_interrupt_mask(self, mask: int) -> None:
        self.write_int(0xFB, mask, 2)

    def get_interrupt_control(self) -> int:
        return self.read_int(0xFC)

    def set_interrupt_control(self, control: int) -> None:
        self.write_int(0xFC, control)

    def get_log_level(self) -> int:
        return self.read_int(0xFD)

    def set_log_level(self, level: int) -> None:
        self.write_int(0xFD, level)

    def get_reset(self) -> Reset | None:
        reset = self.read_int(0xFE, 1)

        try:
            return Reset(reset)
        except ValueError:
            return None

    def set_reset(self, reset: Reset) -> None:
        self.write_int(0xFE, reset)

    def __str__(self) -> str:
        return f"{self.type}[" \
               f"bus={self.bus.id}, " \
               f"address=0x{self.address:02X}" \
               "]"

    RESET_INTERRUPT_CHANNEL = 0x1 << 15

class DeviceIo(Device):
    @property
    def type(self) -> str:
        return "IO"

    def get_inputs(self) -> int:
        return self.read_int(0x00)

    def get_outputs(self) -> int:
        return self.read_int(0x01)

    def set_outputs(self, outputs: int, mask: int = 0x3F) -> None:
        if outputs < 0 or outputs > 0x3F:
            raise ValueError(f"Wrong outputs: 0x{outputs:02X}")
        if mask < 0 or mask > 0x3F:
            raise ValueError(f"Wrong mask: 0x{mask:02X}")

        if mask != 0:
            self.write(0x01, bytes([outputs, mask]))

    def get_output(self, port: int) -> int:
        if port < 0 or port > 5:
            raise ValueError(f"Wrong output port: {port}")

        return self.read_int(0x02 + port)

    def set_output(self, port: int, value: int) -> None:
        if port < 0 or port > 5:
            raise ValueError(f"Wrong output port: {port}")
        if value < 0 or value > 255:
            raise ValueError(f"Wrong output value: {value}")

        self.write_int(0x02 + port, value)

    def is_backup_mode(self) -> bool:
        return self.read_int(0x08) != 0

    # pylint: disable=invalid-name
    @staticmethod
    def INPUT_INTERRUPT_CHANNEL(port: int) -> int:
        if port < 0 or port > 5:
            raise ValueError(f"Wrong input: {port}")

        return 0x1 << port

    # pylint: disable=invalid-name
    @staticmethod
    def OUTPUT_INTERRUPT_CHANNEL(port: int) -> int:
        if port < 0 or port > 5:
            raise ValueError(f"Wrong output: {port}")

        return 0x1 << (6 + port)

    INPUT_INTERRUPT_CHANNELS = 0x003F
    OUTPUT_INTERRUPT_CHANNELS = 0x0FC0
    BACKUP_MODE_INTERRUPT_CHANNEL = 0x1 << 12

class Device1w(Device):
    @property
    def type(self) -> str:
        return "1W"

    def get_temperature(self, port: int) -> float | str | None:
        if port < 0 or port > 9:
            raise ValueError(f"Wrong temperature port: {port}")

        value = self.read_int(port, 2)

        # not present
        if value & 0x0001:
            return None
        # error
        if value & 0x0002:
            return "Error"

        temperature = (value >> 4) & 0x0FFF

        if temperature & 0x0800:
            temperature = temperature & 0x07FF
            return -temperature / 16.0
        else:
            return temperature / 16.0

    # pylint: disable=invalid-name
    @staticmethod
    def PORT_INTERRUPT_CHANNEL(port: int) -> int:
        if port < 0 or port > 9:
            raise ValueError(f"Wrong port: {port}")

        return 0x1 << port

    PORT_INTERRUPT_CHANNELS = 0x03FF

class Bmh:
    def __init__(self) -> None:
        self.__lock = threading.Lock()
        self.__initialized = False
        self.__bus_list: list[Bus] = []
        self.__bus_dict: dict[int, Bus] = {}

    def __initialize(self) -> None:
        if self.__initialized:
            return

        GPIO.setmode(GPIO.BCM)

        bus_list = [Bus(0, 1, 5), Bus(1, 2, 4)]
        bus_dict = {}

        for bus in bus_list:
            bus_dict[bus.id] = bus

        self.__bus_list = bus_list
        self.__bus_dict = bus_dict
        self.__initialized = True

    def get_bus(self, bus_id: int) -> Bus:
        with self.__lock:
            self.__initialize()

            bus_dict = self.__bus_dict

        if bus_id not in bus_dict:
            raise ValueError(f"Unknown bus '{bus_id}'.")

        return bus_dict[bus_id]

    def get_buses(self) -> list[Bus]:
        with self.__lock:
            self.__initialize()

            return self.__bus_list

    def get_device(self, device_id: int) -> Device:
        bus_id = (device_id >> 8) & 0xFF
        device_address = device_id & 0xFF

        bus = self.get_bus(bus_id)

        return bus.get_device(device_address)

    def get_devices(self) -> list[Device]:
        devices = []

        for bus in self.get_buses():
            devices += bus.get_devices()

        return devices

    def scan(self) -> list[Device]:
        for bus in self.get_buses():
            bus.scan()

        return self.get_devices()

    def close(self) -> None:
        with self.__lock:
            if not self.__initialized:
                return

            for bus in self.__bus_list:
                bus.close()

            self.__bus_list = []
            self.__bus_dict = {}

            GPIO.cleanup()

    def __enter__(self) -> None:
        # forcing initialization at this point
        self.get_buses()

    def __exit__(self,
                 exc_type: Type[BaseException] | None,
                 exc_val: BaseException | None,
                 exc_tb: TracebackType | None) -> None:
        self.close()
