from abc import ABC, abstractmethod
import argparse
from datetime import datetime
import logging
import time
import traceback
from typing import Callable, NoReturn, ParamSpec, Type, TypeVar
import sys

import bmh

TypeDevice = TypeVar("TypeDevice", bound = bmh.Device)

T = TypeVar("T")
P = ParamSpec("P")

_LOGGER = logging.getLogger(__name__)

_OPTION_TIMESTAMP = "timestamp"
_OPTIONS = {}

def out(message: str = "") -> None:
    if len(message) == 0:
        print()
        return

    if _OPTION_TIMESTAMP not in _OPTIONS:
        print(message)
        return

    time_str = datetime.now().strftime("%F %T,%f")[:-3]

    print(f"{time_str} {message}")

def format_bus(bus: bmh.Bus) -> str:
    return f"Bus[{bus.id}]"

def format_device(device: bmh.Device) -> str:
    return f"{device.type}[0x{device.id:03X}]"

def format_error(error: Exception) -> str:
    return str(error)

def get_or_error(func: Callable[P, T],
                 *args: P.args, **kwargs: P.kwargs) -> T | str:
    try:
        return func(*args, **kwargs)
    except IOError as e:
        return format_error(e)

class Command(ABC):
    @abstractmethod
    def get_name(self) -> str:
        return ""

    @abstractmethod
    def get_help(self) -> str:
        return ""

    def configure_parser(self, parser: argparse.ArgumentParser) -> None:
        pass

    @abstractmethod
    def run(self, home: bmh.Bmh, args: argparse.Namespace) -> bool:
        return False

class CrcCommand(Command):
    def get_name(self) -> str:
        return "crc"

    def get_help(self) -> str:
        return "stress test bus for crc errors"

    def run(self, home: bmh.Bmh, args: argparse.Namespace) -> bool:
        out("Generating traffic on buses. Errors will be printed.")
        out("Press Ctrl-C to exit.")
        out()

        # setting retries to 1, so it switches off automatic message repeating
        for bus in home.get_buses():
            bus.retries = 1

        devices = home.get_devices()

        if len(devices) == 0:
            out("No devices, skipping test.")
            return False

        start = time.monotonic()

        try:
            while True:
                for device in devices:
                    try:
                        # generating some traffic
                        device.get_interrupt_status()
                    except IOError as e:
                        bus = device.bus

                        out(f"Error on {format_bus(bus)}: {format_error(e)}")

                        messages = bus.messages
                        errors = bus.errors

                        out(f"Messages: {messages}, errors: {errors}. "
                            f"Percentage: {errors / messages * 100:.6f}%")
        except KeyboardInterrupt:
            pass

        stop = time.monotonic()

        out()
        out("Statistics:")

        total_messages = 0

        for bus in home.get_buses():
            if bus.messages == 0:
                percent = 0.0
            else:
                percent = bus.errors / bus.messages * 100

            out(f"{format_bus(bus)}: messages: {bus.messages}, "
                f"errors: {bus.errors}. Percentage: {percent:6f}%")

            total_messages += bus.messages

        elapsed = stop - start

        out(f"Elapsed time: {elapsed:.3f}")
        out(f"Messages / sec: {total_messages / elapsed:.1f}")

        return True

class GetCommand(Command):
    def get_name(self) -> str:
        return "get"

    def get_help(self) -> str:
        return "get device registers"

    def configure_parser(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("-d", "--device-id",
            help = "device id (e.g. 0x111)")

        subparsers = parser.add_subparsers(dest = "get_command",
            required = True, help = "get commands")

        subparsers.add_parser("backup-mode", aliases = ["bm"],
            help = "backup mode (IO)")

        input_parser = subparsers.add_parser("input", aliases = ["in"],
            help = "input state (IO)")
        input_parser.add_argument("port", nargs = "?", type = int,
            help = "port number")

        interrupt_parser = subparsers.add_parser("interrupt", aliases = ["int"],
            help = "interrupt registers")
        interrupt_subparsers = interrupt_parser.add_subparsers(
            dest = "register")

        interrupt_subparsers.add_parser("control", help = "control register")
        interrupt_subparsers.add_parser("mask", help = "mask register")
        interrupt_subparsers.add_parser("status", help = "status register")

        subparsers.add_parser("log",
            help = "log level (0=off, 1=error, 2=info, 3=debug)")

        output_parser = subparsers.add_parser("output", aliases = ["out"],
            help = "output state (IO)")
        output_parser.add_argument("port", nargs = "?", type = int,
            help = "port number")

        subparsers.add_parser("reset", help = "reset (startup) type")

        temperature_parser = subparsers.add_parser("temperature",
            aliases = ["temp"], help = "temperature (1W)")
        temperature_parser.add_argument("port", nargs = "?", type = int,
            help = "temperature port number")

        subparsers.add_parser("version", help = "firmware version")

    def get_devices(self, home: bmh.Bmh,
                    args: argparse.Namespace) -> list[bmh.Device]:
        if args.device_id is None:
            return home.get_devices()
        else:
            device_id = int(args.device_id, 0)
            return [home.get_device(device_id)]

    def iterate_any(self, home: bmh.Bmh, args: argparse.Namespace,
                    function: Callable[[bmh.Device], None]) -> None:
        for device in self.get_devices(home, args):
            function(device)

    def iterate_type(self, home: bmh.Bmh, args: argparse.Namespace,
                     device_type: Type[TypeDevice],
                     function: Callable[[TypeDevice], None]) -> None:
        for device in self.get_devices(home, args):
            if isinstance(device, device_type):
                function(device)

    def is_backup_mode(self, device: bmh.DeviceIo) -> None:
        device_str = format_device(device)
        backup_mode = get_or_error(device.is_backup_mode)

        out(f"{device_str} backup-mode: {backup_mode}")

    def get_input(self, device: bmh.DeviceIo, port: int) -> None:
        device_str = format_device(device)

        try:
            inputs = device.get_inputs()

            if port is None:
                for i in range(0, 6):
                    mask = 0x1 << i
                    value = bool(inputs & mask)
                    out(f"{device_str} input{i}: {value}")
            else:
                mask = 0x1 << port
                value = bool(inputs & mask)
                out(f"{device_str} input{port}: {value}")
        except IOError as e:
            error_str = format_error(e)

            if port is None:
                for i in range(0, 6):
                    out(f"{device_str} input{i}: {error_str}")
            else:
                out(f"{device_str} input{port}: {error_str}")

    def get_interrupt(self, device: bmh.Device, register: str | None) -> None:
        device_str = format_device(device)

        if register is None or register == "control":
            try:
                control = device.get_interrupt_control()
                out(f"{device_str} interrupt control: 0x{control:02X}")
            except IOError as e:
                out(f"{device_str} interrupt control: {format_error(e)}")

        if register is None or register == "mask":
            try:
                mask = device.get_interrupt_mask()
                out(f"{device_str} interrupt mask: 0x{mask:04X}")
            except IOError as e:
                out(f"{device_str} interrupt mask: {format_error(e)}")

        if register is None or register == "status":
            try:
                status = device.get_interrupt_status()
                out(f"{device_str} interrupt status: 0x{status:04X}")
            except IOError as e:
                out(f"{device_str} interrupt status: {format_error(e)}")

    def get_log(self, device: bmh.Device) -> None:
        device_str = format_device(device)
        log_level = get_or_error(device.get_log_level)

        out(f"{device_str} log: {log_level}")

    def get_output(self, device: bmh.DeviceIo, port: int) -> None:
        device_str = format_device(device)

        if port is None:
            for i in range(0, 6):
                output = get_or_error(device.get_output, i)
                out(f"{device_str} output{i}: {output}")
        else:
            output = get_or_error(device.get_output, port)
            out(f"{device_str} output{port}: {output}")

    def get_reset(self, device: bmh.Device) -> None:
        device_str = format_device(device)
        reset = get_or_error(device.get_reset)

        out(f"{device_str} reset: {reset}")

    def get_temperature(self, device: bmh.Device1w, port: int) -> None:
        device_str = format_device(device)

        if port is None:
            for i in range(0, 10):
                temperature = get_or_error(device.get_temperature, i)
                out(f"{device_str} temperature{i}: {temperature}")
        else:
            temperature = get_or_error(device.get_temperature, port)
            out(f"{device_str} temperature{port}: {temperature}")

    def get_version(self, device: bmh.Device) -> None:
        device_str = format_device(device)

        out(f"{device_str}: version: {device.version}")

    def run(self, home: bmh.Bmh, args: argparse.Namespace) -> bool:
        match args.get_command:
            case "bm" | "backup-mode":
                self.iterate_type(home, args, bmh.DeviceIo,
                    self.is_backup_mode)
            case "in" | "input":
                self.iterate_type(home, args, bmh.DeviceIo,
                    lambda device: self.get_input(device, args.port))
            case "int" | "interrupt":
                self.iterate_any(home, args,
                    lambda device: self.get_interrupt(device, args.register))
            case "log":
                self.iterate_any(home, args, self.get_log)
            case "out" | "output":
                self.iterate_type(home, args, bmh.DeviceIo,
                    lambda device: self.get_output(device, args.port))
            case "reset":
                self.iterate_any(home, args, self.get_reset)
            case "temp" | "temperature":
                self.iterate_type(home, args, bmh.Device1w,
                    lambda device: self.get_temperature(device, args.port))
            case "version":
                self.iterate_any(home, args, self.get_version)

        return True

class ListCommand(Command):
    def get_name(self) -> str:
        return "list"

    def get_help(self) -> str:
        return "list devices"

    def run(self, home: bmh.Bmh, args: argparse.Namespace) -> bool:
        buses = home.get_buses()

        for bus in buses:
            out(f"{format_bus(bus)}:")

            for device in bus.get_devices():
                out(f"  {format_device(device)} (version: {device.version})")

        return True

class SetCommand(Command):
    def get_name(self) -> str:
        return "set"

    def get_help(self) -> str:
        return "set device registers"

    def configure_parser(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("device_id", help = "device id (e.g. 0x111)")

        subparsers = parser.add_subparsers(dest = "set_command",
            required = True, help = "set commands")

        interrupt_parser = subparsers.add_parser("interrupt", aliases = ["int"],
            help = "interrupt registers")
        interrupt_subparsers = interrupt_parser.add_subparsers(
            dest = "register", required = True)

        interrupt_control_parser = interrupt_subparsers.add_parser(
            "control", help = "control register")
        interrupt_control_parser.add_argument("value", type = str,
            help = "control value")

        interrupt_mask_parser = interrupt_subparsers.add_parser(
            "mask", help = "mask register")
        interrupt_mask_parser.add_argument("value", type = str,
            help = "mask value")

        log_parser = subparsers.add_parser("log", help = "log level")
        log_parser.add_argument("level", type = int,
            help = "log level (0=off, 1=error, 2=info, 3=debug)")

        output_parser = subparsers.add_parser("output", aliases = ["out"],
            help = "output state (IO)")
        output_parser.add_argument("port", type = int,
            help = "port number")
        output_parser.add_argument("value",
            help = "output value (0-255, on, off)")

        reset_parser = subparsers.add_parser("reset", help = "reset device")
        reset_parser.add_argument("reset", type = int,
            help = "reset type (1=manual, 2=watchdog)")

    def set_interrupt(self, device: bmh.Device,
                      register: str, value: str) -> None:
        value_int = int(value, 0)

        match register:
            case "control":
                device.set_interrupt_control(value_int)
            case "mask":
                device.set_interrupt_mask(value_int)
            case _:
                raise ValueError("Unknown register '{register}'.")

    def run(self, home: bmh.Bmh, args: argparse.Namespace) -> bool:
        device_id = int(args.device_id, 0)
        device = home.get_device(device_id)

        match args.set_command:
            case "int" | "interrupt":
                self.set_interrupt(device, args.register, args.value)
            case "log":
                device.set_log_level(args.level)
            case "out" | "output":
                if args.value == "off":
                    value = 0
                elif args.value == "on":
                    value = 255
                else:
                    value = int(args.value, 0)

                if isinstance(device, bmh.DeviceIo):
                    device.set_output(args.port, value)
            case "reset":
                device.set_reset(args.reset)

        return True

class TestCommand(Command):
    def get_name(self) -> str:
        return "test"

    def get_help(self) -> str:
        return "run diagnostics"

    def test_version(self, bus: bmh.Bus, indent: str) -> bool:
        success = True

        for device in bus.get_devices():
            _LOGGER.info("%sDevice: %s (version: %d)",
                        indent, format_device(device), device.version)

            if device.version < bmh.VERSION:
                _LOGGER.warning("%sDevice version '%d' is older than "
                                "latest '%d'.", indent, device.version,
                                bmh.VERSION)

                success = False

        return success

    def test_interrupt(self, bus: bmh.Bus, indent: str) -> bool:
        devices = bus.get_devices()

        _LOGGER.debug("%sDisabling interrupt generation.", indent)

        for device in devices:
            device.set_interrupt_control(0x00)

        # giving 1ms to clear the interrupt
        time.sleep(0.001)

        if bus.is_interrupt():
            _LOGGER.error("%sInterrupt is present on bus after disabling.",
                          indent)
            return False

        success = True

        for device in devices:
            _LOGGER.info("%sTesting device '%s'.",
                         indent, format_device(device))
            _LOGGER.debug("%s  Raising interrupt.", indent)

            device.set_interrupt_control(0x02)
            time.sleep(0.001)

            if not bus.is_interrupt():
                _LOGGER.error("%s  Interrupt is not present on bus.", indent)
                success = False
                continue

            _LOGGER.debug("%s  Clearing interrupt.", indent)

            device.set_interrupt_control(0x00)
            time.sleep(0.001)

            if bus.is_interrupt():
                _LOGGER.error("%s  Interrupt is present on bus after clearing.",
                              indent)
                success = False
                continue

        _LOGGER.debug("%sRe-enabling interrupt generation.", indent)

        for device in devices:
            # enabling interrupt generation
            device.set_interrupt_control(0x01)

        return success

    def test_bus(self, bus: bmh.Bus) -> bool:
        bus_str = format_bus(bus)
        success = True

        _LOGGER.info("Testing bus '%s'.", bus_str)
        _LOGGER.info("  Found %d device(s).", len(bus.get_devices()))

        _LOGGER.info("  Testing device versions.")

        if not self.test_version(bus, " " * 4):
            success = False

        _LOGGER.info("  Testing interrupts.")

        if not self.test_interrupt(bus, " " * 4):
            success = False

        _LOGGER.info("Testing of bus '%s' is done. Success: %s",
                     bus_str, success)

        return success

    def run(self, home: bmh.Bmh, args: argparse.Namespace) -> bool:
        success = True

        for bus in home.get_buses():
            if not self.test_bus(bus):
                success = False

        return success

class WaitCommand(Command):
    def get_name(self) -> str:
        return "wait"

    def get_help(self) -> str:
        return "wait for interrupts"

    def check_io(self, device: bmh.DeviceIo, status: int) -> None:
        device_str = format_device(device)

        if status & bmh.DeviceIo.INPUT_INTERRUPT_CHANNELS:
            try:
                inputs = device.get_inputs()

                for i in range(0, 6):
                    if status & bmh.DeviceIo.INPUT_INTERRUPT_CHANNEL(i):
                        mask = 0x1 << i
                        value = bool(inputs & mask)
                        out(f"{device_str} input{i}: {value}")
            except IOError as e:
                error_str = format_error(e)

                for i in range(0, 6):
                    if status & bmh.DeviceIo.INPUT_INTERRUPT_CHANNEL(i):
                        out(f"{device_str} input{i}: {error_str}")

        for i in range(0, 6):
            if status & bmh.DeviceIo.OUTPUT_INTERRUPT_CHANNEL(i):
                output = get_or_error(device.get_output, i)
                out(f"{device_str} output{i}: {output}")

        if status & bmh.DeviceIo.BACKUP_MODE_INTERRUPT_CHANNEL:
            backup_mode = get_or_error(device.is_backup_mode)
            out(f"{device_str} backup mode: {backup_mode}")

    def check_1w(self, device: bmh.Device1w, status: int) -> None:
        device_str = format_device(device)

        for i in range(0, 10):
            if status & bmh.Device1w.PORT_INTERRUPT_CHANNEL(i):
                temperature = get_or_error(device.get_temperature, i)
                out(f"{device_str} temperature{i}: {temperature}")

    def interrupt_handler(self, device: bmh.Device, status: int) -> None:
        device_str = format_device(device)

        match device:
            case bmh.DeviceIo():
                self.check_io(device, status)
            case bmh.Device1w():
                self.check_1w(device, status)
            case _:
                out(f"{device_str}: unknown device")

        if status & bmh.Device.RESET_INTERRUPT_CHANNEL:
            reset = get_or_error(device.get_reset)
            out(f"{device_str} reset: {reset}")

    def run(self, home: bmh.Bmh, args: argparse.Namespace) -> bool:
        out("Waiting for interrupts on all buses.")
        out("Press Ctrl-C to exit.")
        out()

        for bus in home.get_buses():
            bus.interrupt_handler = self.interrupt_handler

        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            pass

        out()
        out("Statistics:")

        for bus in home.get_buses():
            out(f"{format_bus(bus)}: {bus.interrupts} interrupts")

            for device in bus.get_devices():
                out(f"  {format_device(device)}: "
                    f"{device.interrupts} interrupts")

        return True

def main() -> NoReturn:
    parser = argparse.ArgumentParser(
        prog = "bmh",
        description = "BMH CLI tool"
    )

    parser.add_argument("-t", "--timestamp", action = "store_true",
                        help = "timestamp")
    parser.add_argument("-v", "--verbose", action = "count",
        help = "verbose logging (-vv to trace messages)")

    subparsers = parser.add_subparsers(dest = "command", required = True,
        help = "commands")

    commands: list[Command] = [
            CrcCommand(),
            GetCommand(),
            ListCommand(),
            SetCommand(),
            TestCommand(),
            WaitCommand()
        ]

    for command in commands:
        subparser = subparsers.add_parser(command.get_name(),
                                          help = command.get_help())
        command.configure_parser(subparser)

    args = parser.parse_args()

    verbose = args.verbose or 0
    level = logging.INFO

    if verbose >= 1:
        level = logging.DEBUG
    if verbose >= 2:
        bmh.TRACE_MESSAGES = True

    if args.timestamp:
        formatter = "%(asctime)s [%(levelname)-7s] %(message)s"
        _OPTIONS[_OPTION_TIMESTAMP] = True
    else:
        formatter = "[%(levelname)-7s] %(message)s"

    logging.basicConfig(level=level, format=formatter)

    home = bmh.Bmh()

    with home:
        try:
            for command in commands:
                if args.command == command.get_name():
                    if command.run(home, args):
                        sys.exit(0)
                    else:
                        sys.exit(1)
        # pylint: disable=broad-exception-caught
        except Exception:
            if args.verbose:
                print(traceback.format_exc(), file = sys.stderr)
            else:
                print("error:", sys.exc_info()[1], file = sys.stderr)

            sys.exit(1)

    # should not reach
    sys.exit(0)

if __name__ == "__main__":
    main()
